## MLflow with TensorFlow

This folder contains two subdirectories: `tf1`, which demonstrates how to use MLflow with TF 1.X, and `tf2`, which demonstrates how to use MLflow with Tf 2.0.